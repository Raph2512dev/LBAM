from Classes import *
import asyncio
import argparse

async def _connect(port, slot, func, parameter=""):
    if func == "slots":
        await apGetSlots(port, slot)
    elif func == "item":
        await apGetItem(port, slot, parameter)
    elif func == "release":
        await apReleaseSlot(port, slot)
    elif func == "status":
        await apGetStatus(port, slot)

    ret = f'Connected to archipelago.gg:{port}'

def GetSlots(port, slot):
    asyncio.run(_connect(port, slot, "slots"))

def GetItem(port, slot, item):
    asyncio.run(_connect(port, slot, "item", item))

def ReleaseSlot(port, slot):
    asyncio.run(_connect(port, slot, "release"))

def Status(port, slot):
    asyncio.run(_connect(port, slot, "status"))

def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(description="Connect to archipelago.gg to get info and run commands")
    parser.add_argument("port", type=int, help="The port to connect to")
    parser.add_argument("slot", type=str, help="The slot to connect with")
    parser.add_argument("function", choices=["GetSlots", "GetItem", "ReleaseSlot", "Status"], help="The function to execute")
    parser.add_argument("--item", type=str, help="The item to get (only used with GetItem)", default="")

    # Parse arguments
    args = parser.parse_args()

    # Call the appropriate function based on arguments
    if args.function == "GetSlots":
        GetSlots(args.port, args.slot)
    elif args.function == "GetItem":
        if args.item:
            GetItem(args.port, args.slot, args.item)
        else:
            print("Error: --item is required for GetItem function.")
    elif args.function == "ReleaseSlot":
        ReleaseSlot(args.port, args.slot)
    elif args.function == "Status":
        Status(args.port, args.slot)

if __name__ == "__main__":
    main()
