import requests
import re
import asyncio
import websockets
import json
import shutil
from Packets import *
from asyncio import Event

async def apGetSlots(port: int, slot: str):
    uri = f"wss://archipelago.gg:{port}"

    try:
        async with websockets.connect(uri) as websocket:
            print(f"Connected to Archipelago server on port {port}")

            Connect = getConnect(slot)
            await websocket.send(Connect)
            print(f"Sent Connect packet {Connect}")

            response = await websocket.recv()
            print(f"Response from server: {response}")

            try:
                Get = getSlots()
                await websocket.send(Get)
                response = await websocket.recv()
                data = json.loads(response)
                for item in data:
                    if item.get("cmd") == "Retrieved":
                        keys = item.get("keys", {})
                        for key, value in keys.items():
                            await channel.send(key)

                if isinstance(response, str):
                    response = json.loads(response)

                slot_info = response[0]["slot_info"]
                slots = {info["name"]: info["game"] for info in slot_info.values()}
                with open("slots.json", "w") as json_file:
                    json.dump(slots, json_file, indent=4)
                shutil.copyfile("slots.json", "slots.txt")
            except:
                pass
            await asyncio.sleep(5)
        print("Closing WebSocket.")


    except Exception as e:
        print(f"Failed to connect or communicate: {e}")

    finally:
        await websocket.close()
        print("WebSocket connection closed")

async def apGetItem(port: int, slot: str, item: str):
    uri = f"wss://archipelago.gg:{port}"

    try:
        async with websockets.connect(uri) as websocket:
            print(f"Connected to Archipelago server on port {port}")

            Connect = getConnect(slot)
            await websocket.send(Connect)
            print(f"Sent Connect packet {Connect}")

            response = await websocket.recv()
            print(f"Response from server: {response}")

            try:
                Get = getCommand(f'!getitem {item}')
                await websocket.send(Get)
                hasResponded = True
                while hasResponded:
                    try:
                        server_message = await websocket.recv()
                        message_data = json.loads(server_message)

                        if(message_data[0]["cmd"] == "PrintJSON"):
                            msg = message_data[0]["data"][0]["text"]
                            if "Cheat console" in msg:
                                print("Message received:", msg)
                                hasResponded = False

                    except Exception as e:
                        print(f"Error while receiving messages: {e}")
                        hasResponded = False
                        break

            except:
                pass
            await asyncio.sleep(5)
        print("Closing WebSocket.")


    except Exception as e:
        print(f"Failed to connect or communicate: {e}")

    finally:
        await websocket.close()
        print("WebSocket connection closed")

async def apReleaseSlot(port: int, slot: str):
    uri = f"wss://archipelago.gg:{port}"

    try:
        async with websockets.connect(uri) as websocket:
            print(f"Connected to Archipelago server on port {port}")

            Connect = getConnect(slot)
            await websocket.send(Connect)
            print(f"Sent Connect packet {Connect}")

            response = await websocket.recv()
            print(f"Response from server: {response}")

            try:
                Get = getCommand(f'!release')
                await websocket.send(Get)
                hasResponded = True
                while hasResponded:
                    try:
                        server_message = await websocket.recv()
                        message_data = json.loads(server_message)

                        if(message_data[0]["cmd"] == "PrintJSON"):
                            msg = message_data[0]["data"][0]["text"]
                            if "Cheat console" in msg:
                                print("Message received:", msg)
                                hasResponded = False

                    except Exception as e:
                        print(f"Error while receiving messages: {e}")
                        hasResponded = False
                        break

            except:
                pass
            await asyncio.sleep(5)
        print("Closing WebSocket.")


    except Exception as e:
        print(f"Failed to connect or communicate: {e}")

    finally:
        await websocket.close()
        print("WebSocket connection closed")

async def apGetStatus(port: int, slot: str):
    uri = f"wss://archipelago.gg:{port}"

    try:
        async with websockets.connect(uri) as websocket:
            print(f"Connected to Archipelago server on port {port}")

            Connect = getConnect(slot)
            await websocket.send(Connect)
            print(f"Sent Connect packet {Connect}")

            response = await websocket.recv()
            print(f"Response from server: {response}")

            try:
                Get = getCommand(f'!status')
                await websocket.send(Get)
                hasResponded = True
                while hasResponded:
                    try:
                        server_message = await websocket.recv()
                        message_data = json.loads(server_message)

                        if(message_data[0]["cmd"] == "PrintJSON"):
                            print(message_data)
                            msg = message_data[0]["data"][0]["text"]
                            if "Player Status on team 0:" in msg:
                                with open("status.txt", "w") as file:
                                    file.write(msg)
                                hasResponded = False

                    except Exception as e:
                        print(f"Error while receiving messages: {e}")
                        hasResponded = False
                        break

            except:
                pass
            await asyncio.sleep(5)
        print("Closing WebSocket.")


    except Exception as e:
        print(f"Failed to connect or communicate: {e}")

    finally:
        await websocket.close()
        print("WebSocket connection closed")
