import json

def getConnect(slot: str) -> str:
    connect_data = [{
        "cmd": "Connect",
        "password": "",
        "game": "",
        "name": slot,
        "uuid": "",
        "version": {
            "major": 0,
            "minor": 5,
            "build": 1,
            "class": "Version"
        },
        "items_handling": 0b000,
        "tags": ["WebHost", "TextOnly"],
        "slot_data": False
    }]
    return json.dumps(connect_data)

def getSlots() -> str:
    # Random get just to get a response that includes slot_info
    get_data = [{
        "cmd": "Get"
    }]
    return json.dumps(get_data)

def getCommand(command):
    get_data = [{"cmd": "Say", "text": command}]
    return json.dumps(get_data)
